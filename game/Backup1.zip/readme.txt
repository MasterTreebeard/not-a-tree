Keybindings:
w - move up
a - move left
s - move down
d - move right
Esc - pause - the game defaults on pause
Delete - kill the game

Goal:
Find the arch and cross through it

Conditions:
If the slimes touch you, you lose.

Barrels are smashable by walking through them

Go into other rooms by walking to the edge of the screen. 
There is a 1 in 2 chance there is a room in every direction. 
The console will print 'Out of Range' if you walk outside the game boundaries. 